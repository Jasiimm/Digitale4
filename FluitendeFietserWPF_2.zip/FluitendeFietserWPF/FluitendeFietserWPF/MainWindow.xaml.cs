﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using FluitendeFietserWPF;
using System.Windows.Threading;
using System.Windows.Shapes;

namespace FluitendeFietserWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private DispatcherTimer timer;
        private int elapsedSeconds;


        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;

           
            MouseDown += MainWindow_MouseDown;
            MouseMove += MainWindow_MouseMove;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);

            elapsedSeconds = 0;
            timer.Tick += (timerSender, timerArgs) =>
            {
                elapsedSeconds++;

                if (elapsedSeconds >= 60)
                {
                    Application.Current.Shutdown();
                }
                else
                {
                    double marginRight = TimerGreen.Margin.Right;
                    TimerGreen.Margin = new Thickness(10, 43.6, marginRight - 16, 5);
                }
            };

            timer.Start();
        }

        private void MainWindow_MouseDown(object sender, MouseButtonEventArgs mouseArgs)
        {
           
            timer.Stop();
            elapsedSeconds = 0;

            
            TimerGreen.Margin = new Thickness(10, 43.6, 43.4, 5);

           
            timer.Start();
        }

        private void MainWindow_MouseMove(object sender, MouseEventArgs mouseArgs)
        {
           
            timer.Stop();
            elapsedSeconds = 0;

           
            TimerGreen.Margin = new Thickness(10, 43.6, 43.4, 5);

            
            timer.Start();
        }

























        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private double accumulatedTotalPrice = 0;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.ComboBoxItem verzeker = (System.Windows.Controls.ComboBoxItem)verzekerCOMBO.SelectedItem;
            System.Windows.Controls.ComboBoxItem service = (System.Windows.Controls.ComboBoxItem)ServiceCombo.SelectedItem;
            System.Windows.Controls.ComboBoxItem fiets = (System.Windows.Controls.ComboBoxItem)FietsCombo.SelectedItem;

            int dagKeer = int.Parse(Tdagg.Text);

            if (fiets.Content.ToString() == "Kies een fiets" || verzeker.Content.ToString() == "Kies een verzekering" || service.Content.ToString() == "Kies een Service")
            {
                MessageBox.Show("Maak een geldige keuze.");
            }
            else
            {
                ListBoxItem fietsItem = new ListBoxItem();
                fietsItem.Content = "Fiets: " + fiets.Content.ToString();
                fietsItem.Name = "newBlock1";
                Bestellingen.Items.Add(fietsItem);

                ListBoxItem serviceItem = new ListBoxItem();
                serviceItem.Content = "Service: " + service.Content.ToString();
                serviceItem.Name = "newBlock2";
                Bestellingen.Items.Add(serviceItem);

                ListBoxItem verzekerItem = new ListBoxItem();
                verzekerItem.Content = "Verzekering: " + verzeker.Content.ToString();
                verzekerItem.Name = "newBlock3";
                Bestellingen.Items.Add(verzekerItem);

                string[] FietsSplit = fiets.Content.ToString().Split('€')[1].Split('/');
                double FietsBedrag = double.Parse(FietsSplit[0]);

                string[] verzekerSplit = verzeker.Content.ToString().Split('€')[1].Split('/');
                double verzekerBedrag = double.Parse(verzekerSplit[0]);

                string[] serviceSplit = service.Content.ToString().Split('€')[1].Split('/');
                double serviceBedrag = double.Parse(serviceSplit[0]);

                double totaalBedrag = (FietsBedrag + verzekerBedrag + serviceBedrag) * dagKeer;
                accumulatedTotalPrice += totaalBedrag;
                Tprijs.Text = "Totaalbedrag : " + accumulatedTotalPrice.ToString("C");

                Tdag.Text = "Dag : " + Tdagg.Text;
            }
        }


        private void Bestellingen_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ListBox listBox = sender as ListBox;
            if (listBox != null && listBox.SelectedItem != null)
            {
                ListBoxItem listBoxItem = listBox.SelectedItem as ListBoxItem;
                if (listBoxItem != null && listBoxItem.Name == "newBlock1" || listBoxItem.Name == "newBlock2" || listBoxItem.Name == "newBlock3")
                {
                    listBox.Items.Remove(listBoxItem);

                    if (listBoxItem.Name == "newBlock1")
                    {
                        string[] FietsSplit = listBoxItem.Content.ToString().Split('€')[1].Split('/');
                        double FietsBedrag = double.Parse(FietsSplit[0]);
                        double totaalBedrag = FietsBedrag * int.Parse(Tdagg.Text);
                        accumulatedTotalPrice -= totaalBedrag;
                    }
                    else if (listBoxItem.Name == "newBlock2")
                    {
                        string[] serviceSplit = listBoxItem.Content.ToString().Split('€')[1].Split('/');
                        double serviceBedrag = double.Parse(serviceSplit[0]);
                        double totaalBedrag = serviceBedrag * int.Parse(Tdagg.Text);
                        accumulatedTotalPrice -= totaalBedrag;
                    }   
                    else if (listBoxItem.Name == "newBlock3")
                    {
                        string[] verzekerSplit = listBoxItem.Content.ToString().Split('€')[1].Split('/');
                        double verzekerBedrag = double.Parse(verzekerSplit[0]);
                        double totaalBedrag = verzekerBedrag * int.Parse(Tdagg.Text);
                        accumulatedTotalPrice -= totaalBedrag;
                    }

                    Tprijs.Text = "Totaalbedrag : " + accumulatedTotalPrice.ToString("C");
                }
            }
        }








        private void Button_Click_1(object sender, RoutedEventArgs e)
        {


            System.Windows.Controls.ComboBoxItem verzeker = (System.Windows.Controls.ComboBoxItem)verzekerCOMBO.SelectedItem;
            System.Windows.Controls.ComboBoxItem service = (System.Windows.Controls.ComboBoxItem)ServiceCombo.SelectedItem;
            System.Windows.Controls.ComboBoxItem fiets = (System.Windows.Controls.ComboBoxItem)FietsCombo.SelectedItem;


            Tprijs.Text = "Totaal prijs:  0,00€";
            Tdag.Text = "Dag : 0";

            Bestellingen.Items.Clear();



            FietsCombo.SelectedItem = FietsCombo.Items[0];
            verzekerCOMBO.SelectedItem = verzekerCOMBO.Items[0];
            ServiceCombo.SelectedItem = ServiceCombo.Items[0];



        }

        private void Afrekenen_Click(object sender, RoutedEventArgs e)
        {


            System.Windows.Controls.ComboBoxItem verzeker = (System.Windows.Controls.ComboBoxItem)verzekerCOMBO.SelectedItem;
            System.Windows.Controls.ComboBoxItem service = (System.Windows.Controls.ComboBoxItem)ServiceCombo.SelectedItem;
            System.Windows.Controls.ComboBoxItem fiets = (System.Windows.Controls.ComboBoxItem)FietsCombo.SelectedItem;



            if (fiets.Content.ToString() == "Kies een fiets" || verzeker.Content.ToString() == "Kies een verzekering" || service.Content.ToString() == "Kies een Service")
            {
                MessageBox.Show("Maak een geldige keuze.");

            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Wil je Afreken (OK) of annuleren (Cancel) ", "Confirmation", MessageBoxButton.OKCancel);

                if (result == MessageBoxResult.OK)
                {
                    MessageBox.Show(Tprijs.Text);

                    Tprijs.Text = "Totaal prijs:  0,00€";
                    Tdag.Text = "Dag : 0";

                    Bestellingen.Items.Clear();




                    FietsCombo.SelectedItem = FietsCombo.Items[0];
                    verzekerCOMBO.SelectedItem = verzekerCOMBO.Items[0];
                    ServiceCombo.SelectedItem = ServiceCombo.Items[0];
                }
                else if (result == MessageBoxResult.Cancel)
                {

                }
            }






        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {


        }

        private void bestellingen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void bestellingen_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void bestellingen_MouseDoubleClick_1(object sender, MouseButtonEventArgs e)
        {

        }

        private void Reken_Click_Click(object sender, RoutedEventArgs e)
        {
            Window1 objWindow1 = new Window1();
            objWindow1.Show();
        }

        private void Bestellingen_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {

        }



    }
}
