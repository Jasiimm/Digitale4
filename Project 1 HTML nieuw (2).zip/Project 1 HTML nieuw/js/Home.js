var counter = 1;
var counter2 = 0 ;
var counter3 = 0 ;
setInterval(function(){
document.getElementById(`radio` + counter).checked = true;
counter++;
if(counter > 4)
{
    counter = 1;
}
},5000)


function fiets(){
    window.setInterval(function(){
        document.getElementById("fiets1").classList.toggle("flipped");
    },5000)
}




      function rentBike() {
        // TSelecteert alle bike elements op de pagina met getElementsByName()
        let bikes = document.getElementsByName("bike");
        let total = 0;
        let selectedBikes = [];

        for (let i = 0; i < bikes.length; i++) {
          if (bikes[i].checked) {
            selectedBikes.push(bikes[i]);
            let bikePrice = parseFloat(
              bikes[i].parentNode.nextElementSibling.textContent
                .replace("€", "")
                .trim()
            );
            total += bikePrice;
          }
        }

        if (selectedBikes.length > 0){
        // als minstenst een fiets geselecteer is maakt de functie een sting aan
          let bikeNames = selectedBikes
            .map((bike) => bike.parentNode.textContent.trim())
            .join(", ");
          alert(
            "U heeft de fiets(en) " +
              bikeNames +
              " gehuurd voor in totaal €" +
              total.toFixed(2) +
              " per dag."
          );
        }
      }

